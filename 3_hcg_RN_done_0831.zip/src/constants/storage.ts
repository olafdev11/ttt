export const SNAP_POINTS = "SNAP_POINTS";
