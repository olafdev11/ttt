export const TICKERS = {
  ethereum: "ETH",
  solana: "SOL",
};
