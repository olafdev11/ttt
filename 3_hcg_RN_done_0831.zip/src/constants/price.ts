// the reason why its so long is because
// this helps avoid rate limiting from the API
// its free so we have to be careful
export const FETCH_PRICES_INTERVAL = 30000;
